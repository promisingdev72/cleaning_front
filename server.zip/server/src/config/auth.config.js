module.exports = {
  secret: 'cleaning-secret-key',
};
